package controlstatements;

public class IFControlStatement {
	public static void main(String[] args) {
		// if(true){ // it will execute}
		// if(false){ // it will not execute}
		int age = 50;
		if (age > 60) {
			System.out.println("eligible for voting....1");
		}
		else if (age > 55) {
			System.out.println("eligible for voting....2");
		}
		
		else if (age > 56) {
			System.out.println("eligible for voting....3");
		}
		else if (age > 18) {
			System.out.println("eligible for voting....4");
		}
		else if (age > 18) {
			System.out.println("eligible for voting....5");
		}
		else if (age > 18) {
			System.out.println("eligible for voting....6");
		}
		else
		{
			System.out.println("not eligible for voting....7");
			
		}
		
		//remining
		
	}
}
