package controlstatements;

public class SWITCHCASE {
	public static void main(String[] args) {
		int percentage = 80;
		
		switch (percentage) {  // 60,70,80
		case 60: 
			System.out.println("C grade...");
			break;
		case 70:
			System.out.println("B grade...");
			break;
		case 80:
			System.out.println("A grade...");
			break;
		}
		
		String day="wedday";
		
		switch(day) {
		case "sunday": System.out.println("chicken..");
		break;
		case "monday": System.out.println("pappu..");
		break;
		case "tuesday": System.out.println("charu..");
		break;
		default:
			System.out.println("daily common food");
		break;
		case "wedday": System.out.println("biryani..");
		break;
		}
		
		
		/*
		 * if (percentage == 60) { System.out.println("C grade..."); } if (percentage ==
		 * 70) { System.out.println("B grade..."); } if (percentage == 80) {
		 * System.out.println("A grade..."); }
		 */

	}

}
