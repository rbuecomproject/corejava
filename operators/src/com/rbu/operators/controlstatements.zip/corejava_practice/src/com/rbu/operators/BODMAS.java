package com.rbu.operators;

public class BODMAS {
public static void main(String[] args) {
	//order of maths execution
	/*Brackets      -h1
	  Order
	  Division      -h2
	  Multiplication-h2
	  Addition      -h3
	  Subtraction   -h3*/
	int result=(1+1)-(2+2)+(3+3);
	System.out.println(result);
	float result2=(3+3)*(2+2)/(3+3);
	System.out.println(result2);
	
	
}
}
