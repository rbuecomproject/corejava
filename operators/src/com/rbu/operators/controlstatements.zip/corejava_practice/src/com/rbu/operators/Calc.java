package com.rbu.operators;

public class Calc {
	int result;//global variable

	public void add(int input1,int input2) {//input1,input2 arguments variables
		result=input1+input2;    //result local variable
		//System.out.println(input1+input2);
		System.out.println(result);
	}
	
	public void sub(int input1,int input2) {
		 result=input1-input2;
		//System.out.println(input1+input2);
		System.out.println(result);
	}
	
	public void mul(int input1,int input2) {
		 result=input1*input2;
		//System.out.println(input1+input2);
		System.out.println(result);
	}
	public void div(int input1,int input2) {
		 result=input1/input2;
		//System.out.println(input1+input2);
		System.out.println(result);
	}
	public void evnOrOdd(int input1,int input2) {
		 result=input1%input2;
		//System.out.println(input1+input2);
		System.out.println(result==0?"even":"odd");
	}
	
	
	public static void main(String[] args) {
		
		Calc c=new Calc();
		// we need to create ref for Calc class than only you can call methods of this class
		c.add(100, 200);
		c.sub(1000,2000);
		c.mul(100, 200);
		c.div(900,9);
		c.evnOrOdd(100, 2);
	}
	
	
	
	
	
	
}
