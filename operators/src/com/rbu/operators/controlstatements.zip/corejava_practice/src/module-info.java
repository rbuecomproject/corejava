/**
 * 
 */
/**
 * 
 */
module corejava_practice {
}